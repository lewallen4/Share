// src/plugin.ts
import { createPlugin } from '@backstage/core-plugin-api';

export const myPlugin = createPlugin({
  id: 'my-plugin',
});