// src/index.ts
import React from 'react';

export const MyPage = () => <div>Hello from Red Hat dev server plugin!</div>;